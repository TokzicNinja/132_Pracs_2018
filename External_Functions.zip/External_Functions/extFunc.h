#ifndef EXTFUNC
#define EXTFUNC

bool isPrime(int num);

#endif